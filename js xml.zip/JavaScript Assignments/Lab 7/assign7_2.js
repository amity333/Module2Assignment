
function populateCatagory()
{

var catagoryObj=window.document.formSubmit.txtCatagory;
var productObj=window.document.formSubmit.txtCatagory;
var catagoryArra=new Array("Electronics","Grocery");
for(var i=0;i<catagoryArra.length;i++)
 {
 catagoryObj.options[i]=new Option
 (catagoryArra[i],catagoryArra[i]);
 }

}


var productArr=new Array();
productArr[0]=new Array("Television","Laptop","Mobile");
productArr[1]=new Array("Soap","Powder");

function populateProduct()
{
 var catagoryArra=new Array("Electronics","Grocery");
 var catagoryDataObj=document.formSubmit.txtCatagory
 var productDataObj=document.formSubmit.txtProduct;

 var indexOfCatagorySelected=catagoryDataObj.selectedIndex;

 if(catagoryArra[0]=="Electronics"){


 for(var j=0;j<productArr[0].length;j++)
 {
 productDataObj.options[j]=new Option
 (productArr[indexOfCatagorySelected][j],productArr[indexOfCatagorySelected][j],productArr[indexOfCatagorySelected][j]);
 }

 }
 else
 {
  for(var j=0;j<productArr[1].length;j++)
 {
 productDataObj.options[j]=new Option
 (productArr[indexOfCatagorySelected][j],productArr[indexOfCatagorySelected][j],productArr[indexOfCatagorySelected][j]);
 }
 }
}

function populateQuantity(){

var qnt=document.formSubmit.txtQnt.value;
var ct=document.formSubmit.txtCatagory.value;
var pro=document.formSubmit.txtProduct.value;

switch(ct)
{
case "Electronics" : if (pro=="Television"){document.formSubmit.txtPrice.value=eval(qnt)*20000;}
    else if (pro=="Laptop"){document.formSubmit.txtPrice.value=eval(qnt)*30000;}
    else if (pro=="Mobile"){document.formSubmit.txtPrice.value=eval(qnt)*10000;}
    break;

case "Grocery" : if (pro=="Soap"){document.formSubmit.txtPrice.value=eval(qnt)*200;}
    else if (pro=="Powder"){document.formSubmit.txtPrice.value=eval(qnt)*900;}
    break;
}
}
